package com.example.a2024dachuang;

import static java.lang.Math.max;
import static java.lang.Math.min;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.TextView;

public class TSEModel_2spk
{
    private final String TAG = "TSEModel_2spk";
    private final Context context;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    private final ModelInference tsemodel;
    private final AudioManager.ModelStateListener modelStateListener;
    public AudioManager inputManager, embed1Manager, embed2Manager, output1Manager,output2Manager;

    private float[] model_input , model_emb , model_output;

    public TSEModel_2spk(Context context, String modelPath, AudioManager.ModelStateListener modelStateListener) throws Exception {
        this.context = context;
        this.tsemodel = new ModelInference(context,modelPath);
        this.modelStateListener = modelStateListener;
        this.inputManager = new AudioManager(context,null , modelStateListener);
        this.embed1Manager = new AudioManager(context,null , modelStateListener);
        this.embed2Manager = new AudioManager(context,null , modelStateListener) ;
        this.output1Manager = new AudioManager(context,null , modelStateListener);
        this.output2Manager = new AudioManager(context,null , modelStateListener);

    }

    public void bindManagerStatusText(String Tag , AudioManager manager, TextView textView){
        manager.setAudioStateListener(new AudioManager.AudioStateListener() {
            @Override
            public void updateStatusText(String text) {
                String show = "[" + Tag + "]:" + text;
                textView.setText(show);
            }
        });
    }

    public void testWork(){
        //把输入1的信息导入输出1然后检查效果
        output1Manager.setCurrentSamples(inputManager.getCurrentSamples());
        output1Manager.setCurrentChannels(inputManager.getCurrentChannels());
        output1Manager.setCurrentEncoding(inputManager.getCurrentEncoding());
        output1Manager.setCurrentSampleRate(inputManager.getCurrentSampleRate());
        output1Manager.LoadAudioFromFloat();
    }

    public void infer(){
        new Thread(() -> {
            if(inputManager.getCurrentSamples() == null){
                uiHandler.post(() -> modelStateListener.updateStatusText("未加载输入音频，无法推理！"));
                return;
            }
            uiHandler.post(() -> modelStateListener.updateStatusText("开始加载输入"));

            float [] input_sample = inputManager.getCurrentSamples();
            model_input = new float[input_sample.length * 2];

            //填充输入输出。2维度都是一样的，一个分离spk1，一个分离spk2。
            for (int i = 0; i < input_sample.length ; i++){
                model_input[i] = input_sample[i];
            }
            for (int i = 0; i < input_sample.length ; i++){
                model_input[i + input_sample.length] = input_sample[i];
            }

            float [] emb1 = embed1Manager.getCurrentSamples();
            float [] emb2 = embed2Manager.getCurrentSamples();
            // min 参数训练 决定 emb 取 min
            int emblen = min(emb1.length , emb2.length);
            model_emb = new float[emblen * 2];

            //填充embeddings
            for(int i = 0; i < emblen;i++){
                model_emb[i] = emb1[i];
            }
            for(int i = 0; i < emblen;i++){
                model_emb[i+emblen] = emb2[i];
            }

            long [] inputshape = {2,input_sample.length};
            long [] embshape = {2,emblen};

            uiHandler.post(() -> modelStateListener.updateStatusText("开始推理"));

            //开始推理
            long startTime = System.currentTimeMillis();
            model_output = tsemodel.infer(model_input, model_emb, inputshape, embshape);
            long endTime = System.currentTimeMillis();

            uiHandler.post(() -> modelStateListener.updateStatusText("完成推理，用时" + (endTime-startTime) + "ms"));
            Log.d(TAG,"完成推理,用时"+ (endTime-startTime) + "ms");
            // 填充输出Manager
            float [] out1 = new float[input_sample.length];
            float [] out2 = new float[input_sample.length];

            //归一化
            float absmax = 0;

            for (int i = 0; i < input_sample.length ; i++) {
                absmax = Math.max(Math.abs(model_output[i]), absmax);
            }
            for (int i = 0; i < input_sample.length ; i++){
                out1[i] = model_output[i] / absmax;
            }

            absmax = 0;

            for (int i = 0; i < input_sample.length ; i++){
                absmax = Math.max(Math.abs(model_output[i + input_sample.length]),absmax);
            }

            for (int i = 0; i < input_sample.length ; i++){
                out2[i] = model_output[i + input_sample.length] / absmax;
            }

            output1Manager.setCurrentSamples(out1);
            output1Manager.setCurrentEncoding(inputManager.getCurrentEncoding());
            output1Manager.setCurrentChannels(inputManager.getCurrentChannels());
            output1Manager.setCurrentSampleRate(inputManager.getCurrentSampleRate());
            output1Manager.LoadAudioFromFloat();

            output2Manager.setCurrentSamples(out2);
            output2Manager.setCurrentEncoding(inputManager.getCurrentEncoding());
            output2Manager.setCurrentChannels(inputManager.getCurrentChannels());
            output2Manager.setCurrentSampleRate(inputManager.getCurrentSampleRate());
            output2Manager.LoadAudioFromFloat();

        }).start();

    }}
