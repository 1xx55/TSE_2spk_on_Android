package com.example.a2024dachuang;

import org.pytorch.IValue;
import org.pytorch.Module;
import org.pytorch.Tensor;

import android.content.Context;
import android.util.Log;


public class ModelInference {
    private Module module;
    private static final String TAG = "ModelInference";

    public ModelInference(Context context, String modelname) throws Exception {
        // 加载模型
        String filePath = FileUtils.assetFilePath(context, modelname);
        if (filePath != null) {
            // 使用文件路径加载模型或其他操作
            Log.d(TAG, "Model loading from: " + filePath);

            module = Module.load(filePath);

            Log.d(TAG, "Model loaded successfully from: " + filePath);
        } else {
            Log.e("MainActivity", "Failed to copy file from assets");
        }
    }

    /**
     * 执行模型推理
     *
     * @param input1 第一个输入张量，形状为 [2, 48000]
     * @param input2 第二个输入张量，形状为 [2, emb_len]
     * @return 输出结果，包含 4 个张量：
     *         - 前三个张量：形状为 [2, 48000]
     *         - 最后一个张量：形状为 [2, 251]
     */
    public float[] infer(float[] input1, float[] input2, long[] inputShape1, long[] inputShape2) {
        // 将输入数据转换为 Tensor
        Log.d(TAG, "Input1 shape: " + arrayToString(inputShape1) + ", length: " + input1.length);
        Log.d(TAG, "Input2 shape: " + arrayToString(inputShape2) + ", length: " + input2.length);

        Tensor tensorInput1 = Tensor.fromBlob(input1, inputShape1);
        Tensor tensorInput2 = Tensor.fromBlob(input2, inputShape2);

        // 将输入张量转换为 IValue
        IValue ivalueInput1 = IValue.from(tensorInput1);
        IValue ivalueInput2 = IValue.from(tensorInput2);

        // 执行推理，传递两个独立的 IValue 参数
        IValue output = module.forward(ivalueInput1, ivalueInput2);

        Tensor[] outputTensors = output.toTensorList();

        // 提取输出张量
        float[][] outputData = new float[outputTensors.length][];
        for (int i = 0; i < outputTensors.length; i++) {
            Tensor outputTensor = outputTensors[i];
            outputData[i] = outputTensor.getDataAsFloatArray();
            Log.d(TAG, "Output" + (i + 1) + " shape: " + arrayToString(outputTensor.shape()) + ", length: " + outputData[i].length);
        }

        // 根据模型代码，只要第一个输出。
        return outputData[0];
    }


    private String arrayToString(long[] array) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < array.length; i++) {
            sb.append(array[i]);
            if (i < array.length - 1) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
}


//        try {
//            // 实例化 ModelInference
//            Log.d("LoadingModel", "[yhyu]: Loding Model");
//            ModelInference modelInference = new ModelInference(this, "avg_bst_jit.pt");
//            Log.d("LoadingModel", "[yhyu]: Load Model Successful");
//
//            // 准备输入数据
//            int v_len = 6666;
//            float[] input1 = new float[3 * 4800]; // 第一个输入张量
//            float[] input2 = new float[3 * v_len]; // 第二个输入张量（v_len 需要根据实际情况设置）
//            long[] shape1 = {3, 4800};
//            long[] shape2 = {3, v_len};
//            for (int i = 0; i < input1.length; i++) {
//                input1[i] = 1.0f; // 填充示例数据
//            }
//            for (int i = 0; i < input2.length; i++) {
//                input2[i] = 1.0f; // 填充示例数据
//            }
//
//            // 执行推理
//            float[][] output = modelInference.infer(input1, input2, shape1, shape2);
//
//            // 处理输出结果
//            for (int i = 0; i < output.length; i++) {
//                System.out.println("Output " + (i + 1) + " length: " + output[i].length);
//            }
//            Log.d("-test-Infer-","infer succ!");
//        } catch (Exception e) {
//            e.printStackTrace();}