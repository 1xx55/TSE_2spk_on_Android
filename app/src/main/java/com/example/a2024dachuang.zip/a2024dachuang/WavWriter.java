package com.example.a2024dachuang;

import android.media.AudioFormat;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class WavWriter
{
    private void writeWavFile(File file, float[] floatSamples, int sampleRate,
                              int channels, int encoding) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(file);
             DataOutputStream dos = new DataOutputStream(fos)) {

            // 根据编码格式处理数据
            switch (encoding) {
                case AudioFormat.ENCODING_PCM_8BIT:
                    write8BitWav(dos, floatSamples, sampleRate, channels);
                    break;
                case AudioFormat.ENCODING_PCM_16BIT:
                    write16BitWav(dos, floatSamples, sampleRate, channels);
                    break;
                case AudioFormat.ENCODING_PCM_FLOAT:
                    writeFloatWav(dos, floatSamples, sampleRate, channels);
                    break;
                default:
                    throw new IllegalArgumentException("Unsupported encoding: " + encoding);
            }
        }
    }

    private void write8BitWav(DataOutputStream dos, float[] floatSamples,
                              int sampleRate, int channels) throws IOException {
        // 转换为8-bit PCM (0-255)
        byte[] pcmSamples = new byte[floatSamples.length];
        for (int i = 0; i < floatSamples.length; i++) {
            pcmSamples[i] = (byte) ((floatSamples[i] * 127.5f) + 127.5f);
        }

        // 写入WAV头 (8-bit)
        writeWavHeader(dos, pcmSamples.length, sampleRate, channels, 8);

        // 写入PCM数据
        dos.write(pcmSamples);
    }

    private void write16BitWav(DataOutputStream dos, float[] floatSamples,
                               int sampleRate, int channels) throws IOException {
        // 转换为16-bit PCM (-32768到32767)
        short[] pcmSamples = new short[floatSamples.length];
        for (int i = 0; i < floatSamples.length; i++) {
            pcmSamples[i] = (short) (floatSamples[i] * Short.MAX_VALUE);
        }

        // 写入WAV头 (16-bit)
        writeWavHeader(dos, pcmSamples.length * 2, sampleRate, channels, 16);

        // 写入PCM数据 (小端序)
        for (short sample : pcmSamples) {
            dos.writeShort(Short.reverseBytes(sample));
        }
    }

    private void writeFloatWav(DataOutputStream dos, float[] floatSamples,
                               int sampleRate, int channels) throws IOException {
        // 32-bit float不需要转换

        // 写入WAV头 (32-bit float)
        writeWavHeader(dos, floatSamples.length * 4, sampleRate, channels, 32);

        // 写入PCM数据 (小端序)
        for (float sample : floatSamples) {
            dos.writeInt(Integer.reverseBytes(Float.floatToIntBits(sample)));
        }
    }

    private void writeWavHeader(DataOutputStream dos, int dataSize,
                                int sampleRate, int channels, int bitsPerSample) throws IOException {
        // 计算总文件大小 (44字节头 + PCM数据大小)
        int totalFileSize = dataSize + 44;

        // 确定音频格式 (1 = PCM, 3 = IEEE float)
        int audioFormat = (bitsPerSample == 32) ? 3 : 1;

        // 写入WAV头
        dos.writeBytes("RIFF");                             // ChunkID
        dos.writeInt(Integer.reverseBytes(totalFileSize));   // ChunkSize
        dos.writeBytes("WAVE");                             // Format
        dos.writeBytes("fmt ");                             // Subchunk1ID
        dos.writeInt(Integer.reverseBytes(16));             // Subchunk1Size (16 for PCM)
        dos.writeShort(Short.reverseBytes((short)audioFormat)); // AudioFormat
        dos.writeShort(Short.reverseBytes((short)channels)); // NumChannels
        dos.writeInt(Integer.reverseBytes(sampleRate));     // SampleRate
        dos.writeInt(Integer.reverseBytes(sampleRate * channels * (bitsPerSample/8))); // ByteRate
        dos.writeShort(Short.reverseBytes((short)(channels * (bitsPerSample/8)))); // BlockAlign
        dos.writeShort(Short.reverseBytes((short)bitsPerSample)); // BitsPerSample
        dos.writeBytes("data");                             // Subchunk2ID
        dos.writeInt(Integer.reverseBytes(dataSize));       // Subchunk2Size
    }
}
